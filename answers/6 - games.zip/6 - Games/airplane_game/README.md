airplane_game
=============

simple airplane game in javascript
